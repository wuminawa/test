# Changelog

## 0.1.0 (2025-09-16)


### Features

* Create Agent Payments Protocol (AP2) ([e66fc0b](https://github.com/google-agentic-commerce/AP2/commit/e66fc0b8f3f3c69fbabae721a4c57a18cf28c4b7))

## 0.2.0 (2026-04-28)


### Features

* Release of V2 ([b4587ac](https://github.com/google-agentic-commerce/AP2/commit/b4587ac1d055888a73b4b21750973cffba961793))

## Unreleased

### aac3aac436cd611a6046536f4bf418f519916b12 （2026-10-27）

主要改动：

- 新增持久化预设商品目录：[catalog.json](/home/xanadu13/Code/AP2/code/samples/python/src/roles/merchant_agent_mcp/catalog.json)
- `search_inventory` 改为使用 DeepSeek 进行商品语义匹配：[server.py:324](/home/xanadu13/Code/AP2/code/samples/python/src/roles/merchant_agent_mcp/server.py:324)
  - Python 先按价格上限过滤候选商品。
  - LLM 只返回候选商品的 `item_id`，不能生成新商品。
  - 服务端会校验返回的 ID，最多返回 5 个结果：[server.py:557](/home/xanadu13/Code/AP2/code/samples/python/src/roles/merchant_agent_mcp/server.py:557)
  - LLM 调用失败时返回 `search_failed`。
- 本地目录和运行时库存合并加载，运行时数据覆盖同 ID 的预设商品。
- `check_product` 和 `assemble_cart` 使用商品库存，trigger server 的库存覆盖仍然优先。
- Shopping Agent 根据模式选择本地目录搜索或原有 agent 动态生成流程：[consent_agent.md:35](/home/xanadu13/Code/AP2/code/samples/python/src/roles/shopping_agent_v2/shopping_agent/prompts/consent_agent.md:35)
- 前端新增 `Use local catalog for this request` 开关：[App.tsx:108](/home/xanadu13/Code/AP2/code/web-client/src/App.tsx:108)
- 模式会保持到后续商品选择和授权流程结束；取消勾选后恢复原有 agent 生成流程。
- 增加本地库存、DeepSeek 匹配、价格过滤和非法商品 ID 校验测试：[merchant_inventory_tests.py](/home/xanadu13/Code/AP2/code/samples/python/tests/merchant_inventory_tests.py)

当前测试共 13 个，全部通过。
