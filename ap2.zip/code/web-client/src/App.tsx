import {useRef, useState} from 'react';
import './App.scss';
import {MandateViewer} from './components/MandateViewer';
import {MessageRenderer} from './components/MessageRenderer';
import {TypingIndicator} from './components/TypingIndicator';
import {DEFAULT_CHAT_STARTER_MESSAGE} from './config';
import {type ChatState, useChat} from './hooks/useChat';

// ==========================================
// SUB-COMPONENTS
// ==========================================

/** Minimal line-art cart mark (no emoji → renders identically everywhere). */
const CartMark = ({size = 18}: {size?: number}) => (
  <svg
    width={size}
    height={size}
    viewBox="0 0 24 24"
    fill="none"
    stroke="var(--ink)"
    strokeWidth="1.6"
    strokeLinecap="round"
    strokeLinejoin="round"
    aria-hidden="true">
    <path d="M3 4h2.4l2.2 11h10.6l2-7.5H7" />
    <circle cx="9.5" cy="19" r="1.4" fill="var(--c-blue)" stroke="none" />
    <circle cx="17" cy="19" r="1.4" fill="var(--c-blue)" stroke="none" />
  </svg>
);

const AppHeader = ({usedServers}: {usedServers: Set<string>}) => {
  const servers = [
    {
      label: 'Shopping Agent',
      key: 'Shopping Agent',
      className: 'server-shopping',
    },
    {label: 'Merchant MCP', key: 'Merchant MCP', className: 'server-merchant'},
    {
      label: 'Credential Provider MCP',
      key: 'Credential Provider MCP',
      className: 'server-credential',
    },
  ];

  const flow = (import.meta as any).env?.VITE_FLOW;

  return (
    <div className="app-header">
      <div className="logo-container">
        <CartMark />
      </div>
      <div className="title-container">
        <div className="title">
          Delegated Shopper
          {flow === 'x402' && <span className="flow-badge x402">x402</span>}
          {flow === 'card' && <span className="flow-badge card">Card</span>}
        </div>
        <div className="subtitle">
          AP2 · A2A · Human-not-present · Merchant MCP · Credential Provider MCP
        </div>
      </div>
      <div className="server-badges" aria-label="Active services legend">
        {servers.map((b) => (
          <div
            key={b.key}
            className={`server-badge ${usedServers.has(b.key) ? 'active' : ''} ${b.className}`}>
            <div className="dot" />
            <span className="label">{b.label}</span>
          </div>
        ))}
      </div>
    </div>
  );
};

type TabKey = 'chat' | 'mandates';

const TabBar = ({
  activeTab,
  onChange,
  mandateCount,
}: {
  activeTab: TabKey;
  onChange: (t: TabKey) => void;
  mandateCount: number;
}) => (
  <div className="tab-bar">
    <button
      className={`tab ${activeTab === 'chat' ? 'active' : ''}`}
      onClick={() => onChange('chat')}>
      <span className="tab-index">(a)</span>
      Conversation
    </button>
    <button
      className={`tab ${activeTab === 'mandates' ? 'active' : ''}`}
      onClick={() => onChange('mandates')}>
      <span className="tab-index">(b)</span>
      Mandates
      {mandateCount > 0 && <span className="tab-count">{mandateCount}</span>}
    </button>
  </div>
);

const PIPELINE_STEPS = [
  {label: 'Product preview', color: 'var(--c-orange)'},
  {label: 'Mandate signing', color: 'var(--c-blue)'},
  {label: 'Availability monitoring', color: 'var(--c-teal)'},
  {label: 'Autonomous purchase', color: 'var(--c-green)'},
];

const EmptyChatState = ({onPreview}: {onPreview: () => void}) => (
  <div className="empty-state">
    <div className="icon">
      <CartMark size={26} />
    </div>
    <div className="title">Delegated Shopper</div>
    <div className="pipeline" aria-label="Flow overview">
      {PIPELINE_STEPS.map((s, idx) => (
        <span key={s.label} style={{display: 'contents'}}>
          <span className="step">
            <span className="swatch" style={{color: s.color}} />
            {s.label}
          </span>
          {idx < PIPELINE_STEPS.length - 1 && (
            <span className="arrow">→</span>
          )}
        </span>
      ))}
    </div>
    <div className="subtitle">
      Human-not-present purchase via Merchant MCP + Credential Provider MCP
    </div>
    <p className="suggestion">
      Try:{' '}
      <em>
        &ldquo;When is the SuperShoe limited edition Gold sneaker drop? I need
        size 9 women&apos;s.&rdquo;
      </em>
    </p>
    <p className="suggestion-enter-hint">
      or just press <kbd>Enter</kbd> to start
    </p>
    <button type="button" className="demo-button" onClick={onPreview}>
      Preview sample transcript (no backend)
    </button>
  </div>
);

type ChatInputProps = Pick<
  ChatState,
  'handleSend' | 'input' | 'loading' | 'setInput' | 'localCatalogMode' |
  'setLocalCatalogMode' | 'localCatalogResultLimit' |
  'setLocalCatalogResultLimit'
>;

const ChatInput = ({
  input,
  setInput,
  handleSend,
  loading,
  localCatalogMode,
  setLocalCatalogMode,
  localCatalogResultLimit,
  setLocalCatalogResultLimit,
}: ChatInputProps) => (
  <div className="input-area">
    <div className="catalog-controls">
      <label className={`catalog-toggle ${localCatalogMode ? 'active' : ''}`}>
        <input
          type="checkbox"
          checked={localCatalogMode}
          onChange={(e) => setLocalCatalogMode(e.target.checked)}
          disabled={loading}
        />
        <span>Use local catalog for this request</span>
      </label>
      <label className="catalog-limit">
        <span>Show up to</span>
        <input
          type="number"
          min={1}
          max={20}
          step={1}
          value={localCatalogResultLimit}
          onChange={(e) => {
            const next = Number.parseInt(e.target.value, 10);
            if (Number.isFinite(next)) {
              setLocalCatalogResultLimit(Math.min(20, Math.max(1, next)));
            }
          }}
          disabled={loading || !localCatalogMode}
          aria-label="Maximum local catalog results"
        />
        <span>results</span>
      </label>
    </div>
    <div className="chat-row">
      <input
        value={input}
        onChange={(e) => setInput(e.target.value)}
        onKeyDown={(e) =>
          e.key === 'Enter' &&
          !loading &&
          handleSend({fallbackIfEmpty: DEFAULT_CHAT_STARTER_MESSAGE})
        }
        placeholder="e.g. When is the SuperShoe limited edition Gold sneaker drop? I need size 9 women's."
        disabled={loading}
        className="chat-input"
      />
      <button
        onClick={() =>
          handleSend({fallbackIfEmpty: DEFAULT_CHAT_STARTER_MESSAGE})
        }
        disabled={loading}
        className="send-button">
        Send
      </button>
    </div>
  </div>
);

// ==========================================
// MAIN APP COMPONENT
// ==========================================

export default function App() {
  const chatState: ChatState = useChat();
  const [activeTab, setActiveTab] = useState<TabKey>('chat');
  const bottomRef = useRef<HTMLDivElement>(null);

  return (
    <div className="app-container">
      <AppHeader usedServers={chatState.usedServers} />
      <TabBar
        activeTab={activeTab}
        onChange={setActiveTab}
        mandateCount={chatState.mandates.length}
      />

      {activeTab === 'chat' ? (
        <>
          <div className="messages-container">
            {chatState.messages.length > 0 ? (
              <div className="messages-list">
                {chatState.messages.map((msg) => (
                  <MessageRenderer
                    key={msg.id}
                    msg={msg}
                    chatState={chatState}
                  />
                ))}
                {chatState.loading && (
                  <div className="msg-agent">
                    <TypingIndicator />
                  </div>
                )}
              </div>
            ) : (
              <>
                <EmptyChatState onPreview={chatState.loadSampleTranscript} />
                {chatState.loading && (
                  <div className="msg-agent">
                    <TypingIndicator />
                  </div>
                )}
              </>
            )}
            {chatState.messages.length > 0 && (
              <button
                type="button"
                className="scroll-to-bottom-button"
                onClick={() =>
                  bottomRef.current?.scrollIntoView({
                    behavior: 'smooth',
                    block: 'end',
                  })
                }>
                ↓ Jump to latest
              </button>
            )}
            <div ref={bottomRef} />
          </div>

          <ChatInput
            input={chatState.input}
            setInput={chatState.setInput}
            handleSend={chatState.handleSend}
            loading={chatState.loading}
            localCatalogMode={chatState.localCatalogMode}
            setLocalCatalogMode={chatState.setLocalCatalogMode}
            localCatalogResultLimit={chatState.localCatalogResultLimit}
            setLocalCatalogResultLimit={chatState.setLocalCatalogResultLimit}
          />
        </>
      ) : (
        <div className="mandate-tab-container">
          <MandateViewer mandates={chatState.mandates} />
        </div>
      )}
    </div>
  );
}
