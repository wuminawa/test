/**
 * A canned transcript used ONLY for previewing the UI without the backend
 * services running (opened via the "Preview sample transcript" button on the
 * empty state, or by appending `?demo=1` to the URL).
 *
 * It exercises every card type the human-not-present flow can render:
 * tool-call traces, product preview, inventory options, mandate approval,
 * user action, monitoring board, receipt, and the Mandates tab.
 */
import type {ChatMessage} from '../types';

/* ---------------------------------------------------------- SD-JWT helpers */

function b64url(obj: unknown): string {
  const json = JSON.stringify(obj);
  const bytes = new TextEncoder().encode(json);
  let bin = '';
  bytes.forEach((b) => (bin += String.fromCharCode(b)));
  return btoa(bin).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
}

/** Build an (unsigned, demo-only) SD-JWT: header.payload.sig~disclosure~ */
function fakeSdJwt(payload: Record<string, unknown>, disclosures: unknown[][]): string {
  const header = {alg: 'ES256', typ: 'dc+sd-jwt', kid: 'demo-key-1'};
  const jwt = `${b64url(header)}.${b64url(payload)}.ZGVtby1zaWduYXR1cmU`;
  const discs = disclosures.map((d) => b64url(d)).join('~');
  return `${jwt}~${discs}~`;
}

const ITEM_ID = 'supershoe-gold-le-w9';
const ITEM_NAME = 'SuperShoe Limited Edition — Gold (Women\u2019s 9)';
const NOW = Date.now();
const t = (secondsAgo: number) => NOW - secondsAgo * 1000;

const OPEN_CHECKOUT = fakeSdJwt(
  {
    iss: 'did:web:user.wallet.example',
    iat: Math.floor(t(240) / 1000),
    exp: Math.floor((t(240) + 86_400_000) / 1000),
    delegate_payload: [
      {
        vct: 'ap2.checkout.open',
        constraints: [
          {type: 'checkout.allowed_merchants', allowed: ['did:web:supershoe.example']},
          {
            type: 'checkout.line_items',
            items: [{item_id: ITEM_ID, qty: 1, max_unit_price: 180}],
          },
        ],
      },
    ],
    _sd_alg: 'sha-256',
  },
  [['s4lt1', 'shipping_address', '221B Baker St, London']],
);

const OPEN_PAYMENT = fakeSdJwt(
  {
    iss: 'did:web:user.wallet.example',
    iat: Math.floor(t(240) / 1000),
    delegate_payload: [
      {
        vct: 'ap2.payment.open',
        constraints: [
          {type: 'payment.amount_range', min: 0, max: 180, currency: 'USD'},
          {type: 'payment.allowed_payees', allowed: ['did:web:psp.example']},
        ],
      },
    ],
    _sd_alg: 'sha-256',
  },
  [['s4lt2', 'payment_instrument', {type: 'card', last4: '4242', network: 'VISA'}]],
);

const CLOSED_PAYMENT = fakeSdJwt(
  {
    iss: 'did:web:shopping-agent.example',
    iat: Math.floor(t(5) / 1000),
    transaction_id: 'txn_7f3a9c',
    payment_amount: {amount: 17400, currency: 'USD'},
    payment_instrument: {type: 'card', description: 'VISA \u2022\u2022\u2022\u20224242 (DPAN)'},
  },
  [['s4lt3', 'merchant', 'did:web:supershoe.example']],
);

/* ----------------------------------------------------------------- messages */

export function buildSampleTranscript(): ChatMessage[] {
  let i = 0;
  const id = () => `demo_${i++}`;

  return [
    {
      id: id(),
      role: 'user',
      text: 'When is the SuperShoe limited edition Gold sneaker drop? I need size 9 women\u2019s.',
      timestamp: t(300),
    },
    {
      id: id(),
      role: 'agent',
      artifactData: {
        type: 'tool_call',
        tool: 'search_inventory',
        server: 'Merchant MCP',
        message: 'query="SuperShoe gold limited edition" size=W9',
      },
      timestamp: t(296),
    },
    {
      id: id(),
      role: 'agent',
      text: 'The Gold limited edition hasn\u2019t gone live yet \u2014 here is what the merchant has published so far.',
      artifactData: {
        type: 'product_preview_unavailable',
        product_name: 'SuperShoe Limited Edition \u2014 Gold',
        product_subtitle: 'Women\u2019s 9 \u00b7 Metallic knit \u00b7 Numbered run of 500',
        image_emoji: '\ud83d\udc5f',
        typical_list_price: 190,
        drop_scheduled_hint: 'Friday 10:00 PT',
        sku_preview_id: ITEM_ID,
      },
      timestamp: t(292),
    },
    {
      id: id(),
      role: 'user',
      text: 'Buy it automatically when it drops, as long as it\u2019s under $180.',
      timestamp: t(260),
    },
    {
      id: id(),
      role: 'agent',
      artifactData: {
        type: 'tool_call',
        tool: 'check_product',
        server: 'Merchant MCP',
        message: `item_id=${ITEM_ID}`,
      },
      timestamp: t(256),
    },
    {
      id: id(),
      role: 'agent',
      artifactData: {
        type: 'inventory_options',
        matches: [
          {item_id: ITEM_ID, name: ITEM_NAME, price: 190, stock: 0},
          {item_id: 'supershoe-silver-le-w9', name: 'SuperShoe Limited Edition \u2014 Silver (Women\u2019s 9)', price: 165, stock: 12},
          {item_id: 'supershoe-core-w9', name: 'SuperShoe Core \u2014 White (Women\u2019s 9)', price: 120, stock: 40},
        ],
        selected: ITEM_ID,
        price_cap: 180,
        qty: 1,
      },
      timestamp: t(254),
    },
    {
      id: id(),
      role: 'agent',
      text: 'I\u2019ll set up a standing authorization. Review the mandate below \u2014 I will only complete the purchase when the item is in stock **and** priced at or below your cap.',
      artifactData: {
        type: 'mandate_request',
        item_id: ITEM_ID,
        item_name: ITEM_NAME,
        price_cap: 180,
        qty: 1,
        constraint_focus: 'availability',
        available: false,
        constraints: {price_lt: 180},
        current_price: 190,
        payment_method: 'card',
      },
      timestamp: t(250),
    },
    {
      id: id(),
      role: 'user_action',
      userActionLabel: 'Mandate signed',
      userActionSublabel: 'biometric',
      timestamp: t(240),
    },
    {
      id: id(),
      role: 'agent',
      artifactData: {
        type: 'mandates_signed',
        open_checkout_mandate: OPEN_CHECKOUT,
        open_payment_mandate: OPEN_PAYMENT,
      },
      timestamp: t(240),
    },
    {
      id: id(),
      role: 'agent',
      artifactData: {
        type: 'tool_call',
        tool: 'register_mandate',
        server: 'Credential Provider MCP',
        message: 'open checkout + payment mandates stored',
      },
      timestamp: t(238),
    },
    {
      id: id(),
      role: 'agent',
      artifactData: {
        type: 'monitoring',
        item_id: ITEM_ID,
        price_cap: 180,
        qty: 1,
        available: false,
        constraint_focus: 'availability',
        meets_constraints: false,
        current_price: 190,
        message: 'Watching merchant trigger state',
        open_checkout_mandate: OPEN_CHECKOUT,
        open_payment_mandate: OPEN_PAYMENT,
      },
      timestamp: t(230),
    },
    {
      id: id(),
      role: 'system',
      text: 'Merchant trigger received: price 174.00, stock 10',
      timestamp: t(20),
    },
    {
      id: id(),
      role: 'agent',
      artifactData: {
        type: 'tool_call',
        tool: 'create_cart \u2192 checkout',
        server: 'Merchant MCP',
        message: 'price 174.00 \u2264 cap 180.00, stock 10',
      },
      timestamp: t(16),
    },
    {
      id: id(),
      role: 'agent',
      artifactData: {
        type: 'tool_call',
        tool: 'issue_payment_credential',
        server: 'Credential Provider MCP',
        message: 'verified mandate chain \u00b7 issued DPAN',
      },
      timestamp: t(12),
    },
    {
      id: id(),
      role: 'agent',
      artifactData: {
        type: 'mandate_chains_fetched',
        payment_mandate_chain: `${OPEN_PAYMENT}~${CLOSED_PAYMENT}`,
      },
      timestamp: t(8),
    },
    {
      id: id(),
      role: 'agent',
      artifactData: {
        type: 'purchase_complete',
        order_id: 'ord_2f9c1e_supershoe',
        closed_payment_mandate: CLOSED_PAYMENT,
        closed_payment_mandate_content: {
          payment_amount: {amount: 17400, currency: 'USD'},
          payment_instrument: {type: 'card', description: 'VISA \u2022\u2022\u2022\u20224242'},
        },
      } as ChatMessage['artifactData'],
      timestamp: t(5),
    },
    {
      id: id(),
      role: 'agent',
      text: 'Done \u2014 the Gold pair was purchased autonomously for **$174.00** under your $180 cap. The closed payment mandate is available in the Mandates tab.',
      timestamp: t(3),
    },
  ];
}

export const SAMPLE_SELECTED_ITEM_NAME = ITEM_NAME;
