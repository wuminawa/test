"""Tests for shared model-provider configuration."""

from types import SimpleNamespace

import pytest

from common import function_call_resolver, model_config


def _clear_model_environment(monkeypatch: pytest.MonkeyPatch) -> None:
  for name in (
      "AGENT_MODEL_PROVIDER",
      "AGENT_MODEL",
      "DEEPSEEK_API_KEY",
      "DEEPSEEK_MODEL",
      "DEEPSEEK_API_BASE",
  ):
    monkeypatch.delenv(name, raising=False)


def test_google_remains_the_default_provider(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
  _clear_model_environment(monkeypatch)

  assert model_config.get_model_provider() == "google"
  assert model_config.get_agent_model() == model_config.DEFAULT_GOOGLE_MODEL


def test_deepseek_requires_a_key(monkeypatch: pytest.MonkeyPatch) -> None:
  _clear_model_environment(monkeypatch)
  monkeypatch.setenv("AGENT_MODEL_PROVIDER", "deepseek")

  with pytest.raises(RuntimeError, match="DEEPSEEK_API_KEY is empty"):
    model_config.get_agent_model()


def test_deepseek_agent_model_uses_litellm(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
  _clear_model_environment(monkeypatch)
  monkeypatch.setenv("AGENT_MODEL_PROVIDER", "ds")
  monkeypatch.setenv("DEEPSEEK_API_KEY", "test-key")
  monkeypatch.setenv("DEEPSEEK_MODEL", "deepseek-v4-flash")

  model = model_config.get_agent_model()

  assert model.model == "deepseek/deepseek-v4-flash"
  assert model._additional_args["api_base"] == "https://api.deepseek.com"


def test_unknown_provider_is_rejected(monkeypatch: pytest.MonkeyPatch) -> None:
  _clear_model_environment(monkeypatch)
  monkeypatch.setenv("AGENT_MODEL_PROVIDER", "unknown")

  with pytest.raises(ValueError, match="Unsupported AGENT_MODEL_PROVIDER"):
    model_config.get_model_provider()


def test_function_resolver_uses_deepseek_tool_calling(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
  _clear_model_environment(monkeypatch)
  monkeypatch.setenv("AGENT_MODEL_PROVIDER", "deepseek")
  monkeypatch.setenv("DEEPSEEK_API_KEY", "test-key")
  captured: dict[str, object] = {}

  async def first_tool(data_parts, updater, current_task):
    """Use for the first route."""

  async def second_tool(data_parts, updater, current_task):
    """Use for the second route."""

  def fake_completion(**kwargs):
    captured.update(kwargs)
    function = SimpleNamespace(name="second_tool")
    tool_call = SimpleNamespace(function=function)
    message = SimpleNamespace(tool_calls=[tool_call])
    return SimpleNamespace(choices=[SimpleNamespace(message=message)])

  monkeypatch.setattr(
      function_call_resolver, "deepseek_completion", fake_completion
  )

  resolver = function_call_resolver.FunctionCallResolver(
      [first_tool, second_tool], "Select the correct route."
  )

  assert (
      resolver.determine_tool_to_use("use the second route") == "second_tool"
  )
  assert captured["tool_choice"] == "required"
  assert len(captured["tools"]) == 2
