"""Wallet configuration must not silently use a shared signing identity."""

import pytest

from common.x402_constants import get_user_private_key
from eth_account import Account
from eth_account.messages import encode_defunct


@pytest.mark.parametrize("configured_key", [None, "", " \t"])
def test_unconfigured_wallet_cannot_sign(
    monkeypatch: pytest.MonkeyPatch, configured_key: str | None
) -> None:
  if configured_key is None:
    monkeypatch.delenv("X402_USER_PRIVATE_KEY", raising=False)
  else:
    monkeypatch.setenv("X402_USER_PRIVATE_KEY", configured_key)

  with pytest.raises(RuntimeError, match="X402_USER_PRIVATE_KEY is required"):
    get_user_private_key()


def test_signatures_use_the_explicitly_configured_wallet(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
  wallet = Account.create()
  monkeypatch.setenv("X402_USER_PRIVATE_KEY", f" {wallet.key.hex()} ")
  message = encode_defunct(text="AP2 wallet configuration verification")

  signed = Account.sign_message(message, get_user_private_key())

  assert Account.recover_message(message, signature=signed.signature) == wallet.address
