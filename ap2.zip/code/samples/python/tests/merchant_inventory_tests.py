"""Tests for the local merchant catalog search."""

import json

from types import SimpleNamespace

from roles.merchant_agent_mcp import server


def test_load_inventory_merges_catalog_and_runtime_files(
    monkeypatch, tmp_path
) -> None:
  catalog_path = tmp_path / "catalog.json"
  runtime_path = tmp_path / "merchant_inventory.json"
  catalog_path.write_text(
      json.dumps({
          "coffee_001": {"name": "Coffee Maker", "price": 50, "stock": 2},
      }),
      encoding="utf-8",
  )
  runtime_path.write_text(
      json.dumps({
          "coffee_001": {
              "name": "Updated Coffee Maker",
              "price": 45,
              "stock": 1,
          },
      }),
      encoding="utf-8",
  )
  monkeypatch.setattr(server, "_CATALOG_PATH", catalog_path)
  monkeypatch.setattr(server, "_INVENTORY_PATH", runtime_path)

  inventory = server._load_inventory()

  assert inventory["coffee_001"]["name"] == "Updated Coffee Maker"
  assert inventory["coffee_001"]["price"] == 45


def test_search_inventory_uses_llm_matching_and_budget(
    monkeypatch,
) -> None:
  monkeypatch.setattr(
      server,
      "_TEMP_INVENTORY",
      {
          "wireless_headphones_001": {
              "name": "Wireless Headphones",
              "description": "Bluetooth over-ear headphones",
              "price": 120,
              "stock": 4,
          },
          "wired_headphones_001": {
              "name": "Wired Headphones",
              "description": "Basic wired headphones",
              "price": 25,
              "stock": 8,
          },
          "premium_headphones_001": {
              "name": "Premium Headphones",
              "description": "Noise cancelling headphones",
              "price": 200,
              "stock": 3,
          },
      },
  )

  captured: dict[str, object] = {}

  def fake_completion(**kwargs):
    captured.update(kwargs)
    return SimpleNamespace(
        choices=[
            SimpleNamespace(
                message=SimpleNamespace(
                    content=(
                        '{"item_ids": ["wireless_headphones_001", '
                        '"wired_headphones_001"]}'
                    )
                )
            )
        ]
    )

  monkeypatch.setattr(server, "deepseek_completion", fake_completion)

  result = server.search_inventory(
      "something for listening without wires", 150, max_results=1
  )

  assert [item["item_id"] for item in result["matches"]] == [
      "wireless_headphones_001"
  ]
  assert result["matches"][0]["stock"] == 4
  assert captured["response_format"] == {"type": "json_object"}
  assert "something for listening without wires" in str(captured["messages"])
  assert "at most 1 matching item IDs" in str(captured["messages"])
  assert "premium_headphones_001" not in str(captured["messages"])


def test_search_inventory_rejects_invalid_result_limit(monkeypatch) -> None:
  monkeypatch.setattr(
      server,
      "_TEMP_INVENTORY",
      {"coffee_001": {"name": "Coffee Maker", "price": 50, "stock": 2}},
  )

  result = server.search_inventory("coffee", max_results=0)

  assert result == {
      "error": "invalid_result_limit",
      "message": "max_results must be a positive integer",
  }


def test_search_inventory_ignores_llm_ids_outside_candidates(monkeypatch) -> None:
  monkeypatch.setattr(
      server,
      "_TEMP_INVENTORY",
      {"coffee_001": {"name": "Coffee Maker", "price": 50, "stock": 2}},
  )
  monkeypatch.setattr(
      server,
      "deepseek_completion",
      lambda **kwargs: SimpleNamespace(
          choices=[
              SimpleNamespace(
                  message=SimpleNamespace(
                      content=(
                          '{"item_ids": ["not_from_catalog", "coffee_001"]}'
                      )
                  )
              )
          ]
      ),
  )

  result = server.search_inventory("something to brew coffee")

  assert [item["item_id"] for item in result["matches"]] == ["coffee_001"]


def test_check_product_uses_catalog_stock_without_trigger_override(
    monkeypatch,
) -> None:
  monkeypatch.setattr(
      server,
      "_TEMP_INVENTORY",
      {"coffee_001": {"name": "Coffee Maker", "price": 50, "stock": 2}},
  )
  monkeypatch.setattr(
      server, "_trigger_overrides_for", lambda item_id: (None, None)
  )

  result = server.check_product("coffee_001")

  assert result["available"] is True
