# Python Samples for the Agent Payments Protocol (AP2)

Python reference implementations of the AP2 roles (merchant, credentials
provider, payment processor, shopping agent) and end-to-end scenarios that
tie them together.

All paths below are relative to the repository root.

## Layout

- [`scenarios/`](./scenarios) — runnable end-to-end flows. Each scenario has a
  `run.sh` (or `run_*.sh`) that brings up every agent/server it needs.
- [`src/roles/`](./src/roles) — the individual role implementations used by
  those scenarios.
- [`src/common/`](./src/common) — shared utilities (A2A client, message
  builders, server bootstrap, etc.).

For samples in other languages, see [`../go/`](../go) and
[`../android/`](../android). Test certificates used across the samples live
in [`../certs/`](../certs).

## Prerequisites

- Python 3.11+
- [`uv`](https://docs.astral.sh/uv/)
- A DeepSeek API key, a Google API key, or Vertex AI ADC.

## Configuration

Copy the repository-root `.env.example` to `.env` and fill in your own key.
The repository-root `.env` file selects the provider for every Python sample.
For DeepSeek, use:

```
AGENT_MODEL_PROVIDER=deepseek
DEEPSEEK_API_KEY=<your_deepseek_api_key>
DEEPSEEK_MODEL=deepseek-v4-flash
DEEPSEEK_API_BASE=https://api.deepseek.com
```

Change only `DEEPSEEK_MODEL` to `deepseek-v4-pro` if you prefer that model.

The real `.env` is ignored by Git. A safe template is available at
[`../../../.env.example`](../../../.env.example). Do not commit or paste a real
API key into documentation, source code, or chat.

To use Google instead, select the Google provider:

```
AGENT_MODEL_PROVIDER=google
GOOGLE_API_KEY=<your_api_key>
AGENT_MODEL=gemini-3.1-flash-lite-preview
```

Vertex AI ADC remains available with `AGENT_MODEL_PROVIDER=google` and
`GOOGLE_GENAI_USE_VERTEXAI=true`.

The human-not-present x402 scenario additionally requires
`X402_USER_PRIVATE_KEY` in the local `.env` or process environment. There is
no built-in wallet private key. Live broadcast also requires
`FACILITATOR_PRIVATE_KEY`; card-payment scenarios do not use these variables.

## Running a scenario

Pick a scenario and run its script from the repository root. Each script
creates/updates the `uv` virtual environment and starts every agent it
needs.

Human-present (interactive, browser-based shopping agent):

```bash
./code/samples/python/scenarios/a2a/human-present/cards/run.sh
./code/samples/python/scenarios/a2a/human-present/cards/run.sh --payment-method x402
```

Human-not-present (automated / recurring flows):

```bash
./code/samples/python/scenarios/a2a/human-not-present/cards/run.sh
./code/samples/python/scenarios/a2a/human-not-present/x402/run.sh
```

See the README inside each scenario directory for a walkthrough of the
flow and the expected interactions.
