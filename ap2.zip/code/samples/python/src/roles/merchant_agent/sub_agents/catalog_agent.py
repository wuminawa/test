# Copyright 2025 Google LLC
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     https://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""A sub-agent that offers items from its 'catalog'.

Returns Cart objects for browsing. The checkout JWT is created later
when the user selects a cart (via the ``create_checkout`` tool).
"""

import json

from typing import Any

from a2a.server.tasks.task_updater import TaskUpdater
from a2a.types import DataPart, Part, Task, TextPart
from ap2.models.cart import CART_DATA_KEY, Cart
from ap2.models.payment_request import PaymentItem
from common import message_utils
from common.model_config import (
  deepseek_completion,
  get_google_model_name,
  get_model_provider,
)
from common.system_utils import DEBUG_MODE_INSTRUCTIONS
from google import genai
from pydantic import TypeAdapter, ValidationError

from .. import storage


async def find_items_workflow(
    data_parts: list[dict[str, Any]],
    updater: TaskUpdater,
    current_task: Task | None,
) -> None:
  """Find products.

  Use this tool only when the request says 'find products' or contains
  'catalog_search'. Searches the catalog and returns Cart objects.

  Args:
    data_parts: The data parts from the message.
    updater: The task updater to report status.
    current_task: The current task object.
  """
  catalog_search = message_utils.find_data_part("catalog_search", data_parts)
  if not catalog_search:
    error_message = updater.new_agent_message(
        parts=[Part(root=TextPart(text="Missing catalog_search."))]
    )
    await updater.failed(message=error_message)
    return

  prompt = f"""
        Based on the user's request for '{catalog_search}', your task is to
        generate 3 complete, unique and realistic PaymentItem JSON objects.

        You MUST exclude all branding from the PaymentItem `label` field.

    %s
        """ % DEBUG_MODE_INSTRUCTIONS

  try:
    items = _generate_payment_items(prompt)

    for i, item in enumerate(items):
      cart = Cart(
          cart_id=f"cart_{i + 1}",
          item_label=item.label,
          amount=item.amount.value,
          currency=item.amount.currency,
      )
      storage.set_cart_data(cart.cart_id, cart.model_dump())
      await updater.add_artifact(
          [Part(root=DataPart(data={CART_DATA_KEY: cart.model_dump()}))]
      )

    risk_data = _collect_risk_data(updater)
    await updater.add_artifact([
        Part(root=DataPart(data={"risk_data": risk_data})),
    ])
    await updater.complete()
  except ValidationError as e:
    error_message = updater.new_agent_message(
        parts=[Part(root=TextPart(text=f"Invalid product list: {e}"))]
    )
    await updater.failed(message=error_message)
    return


def _generate_payment_items(prompt: str) -> list[PaymentItem]:
  """Generates and validates catalog items using the selected provider."""
  if get_model_provider() == "google":
    llm_response = genai.Client().models.generate_content(
        model=get_google_model_name(),
        contents=prompt,
        config={
            "response_mime_type": "application/json",
            "response_schema": list[PaymentItem],
        },
    )
    return TypeAdapter(list[PaymentItem]).validate_python(llm_response.parsed)

  response = deepseek_completion(
      messages=[
          {
              "role": "system",
              "content": (
                  "Return valid JSON only. The JSON object must have exactly"
                  " one top-level key named items. Its value must be an array"
                  " of exactly three objects in this form:"
                  ' {"items":[{"label":"unbranded item",'
                  '"amount":{"currency":"USD","value":99.99},'
                  '"pending":false,"refund_period":30}]}.'
              ),
          },
          {"role": "user", "content": prompt},
      ],
      response_format={"type": "json_object"},
      max_tokens=2048,
      stream=False,
      timeout=60,
  )
  choices = getattr(response, "choices", None) or []
  if not choices:
    raise ValueError("DeepSeek returned no catalog choices.")
  content = getattr(choices[0].message, "content", None)
  if not isinstance(content, str) or not content.strip():
    raise ValueError("DeepSeek returned empty catalog content.")
  payload = json.loads(content)
  raw_items = payload.get("items") if isinstance(payload, dict) else payload
  return TypeAdapter(list[PaymentItem]).validate_python(raw_items)


def _collect_risk_data(updater: TaskUpdater) -> str:
  risk_data = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...fake_risk_data"
  storage.set_risk_data(updater.context_id, risk_data)
  return risk_data
