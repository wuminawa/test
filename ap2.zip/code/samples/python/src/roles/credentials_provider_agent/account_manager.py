# Copyright 2025 Google LLC
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     https://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""An in-memory manager of a user's 'account details'.

Each 'account' contains a user's payment methods and shipping address.
For demonstration purposes, several accounts are pre-populated with sample data.
"""

from typing import Any

from pydantic import BaseModel, Field


class EIP3009Authorization(BaseModel):
  from_: str = Field(..., alias="from")
  to: str
  value: str
  valid_after: str
  valid_before: str
  nonce: str


class ExactPaymentPayload(BaseModel):
  signature: str
  authorization: EIP3009Authorization


class PaymentPayload(BaseModel):
  x402_version: int
  scheme: str
  network: str
  payload: ExactPaymentPayload


_account_db = {
    "bugsbunny@gmail.com": {
        "shipping_address": {
            "recipient": "Bugs Bunny",
            "organization": "Sample Organization",
            "address_line": ["123 Main St"],
            "city": "Sample City",
            "region": "ST",
            "postal_code": "00000",
            "country": "US",
            "phone_number": "+1-000-000-0000",
        },
        "payment_methods": {
            "card1": {
                "type": "CARD",
                "alias": "American Express ending in 4444",
                "network": [{"name": "amex", "formats": ["DPAN"]}],
                "cryptogram": "fake_cryptogram_abc123",
                "token": "1111000000000000",
                "card_holder_name": "John Doe",
                "card_expiration": "12/2025",
                "card_billing_address": {
                    "country": "US",
                    "postal_code": "00000",
                },
            },
            "card2": {
                "type": "CARD",
                "alias": "American Express ending in 8888",
                "network": [{"name": "amex", "formats": ["DPAN"]}],
                "cryptogram": "fake_cryptogram_ghi789",
                "token": "2222000000000000",
                "card_holder_name": "Bugs Bunny",
                "card_expiration": "10/2027",
                "card_billing_address": {
                    "country": "US",
                    "postal_code": "00000",
                },
            },
            "bank_account1": {
                "type": "BANK_ACCOUNT",
                "account_number": "111",
                "alias": "Primary bank account",
            },
            "digital_wallet1": {
                "type": "DIGITAL_WALLET",
                "brand": "PayPal",
                "account_identifier": "foo@bar.com",
                "alias": "Bugs's PayPal account",
            },
            "x402_wallet": {
                "type": "DIGITAL_WALLET",
                "brand": "x402",
                "alias": "Bugs's x402 Base USDC Wallet",
                "wallet_address": "0xPayerWalletAddress",
                "network": "base",
                "asset": "0x833589fCD6eDb6E08f4c7C32D4f71b54bda02913",
            },
        },
    },
    "daffyduck@gmail.com": {
        "payment_methods": {
            "bank_account1": {
                "type": "BANK_ACCOUNT",
                "brand": "Bank of Money",
                "account_number": "789",
                "alias": "Main checking account",
            }
        },
    },
    "elmerfudd@gmail.com": {
        "payment_methods": {
            "digital_wallet1": {
                "type": "DIGITAL_WALLET",
                "brand": "PayPal",
                "account_identifier": "elmerfudd@gmail.com",
                "alias": "Fudd's PayPal",
            }
        }
    },
}


_token = {}


def create_token(
    email_address: str, payment_method_alias: str
) -> str | dict[str, Any]:
  """Creates and stores a token for an account.

  Args:
    email_address: The email address of the account.
    payment_method_alias: The alias of the payment method.

  Returns:
    The token for the payment method.
  """
  payment_method = get_payment_method_by_alias(
      email_address, payment_method_alias
  )
  if payment_method and payment_method.get("brand") == "x402":
    _token[f"x402_token_{len(_token)}"] = {
        "email_address": email_address,
        "payment_method_alias": payment_method_alias,
        "payment_mandate_id": None,
    }

    # Mock x402 PaymentPayload
    authorization_payload = {
        "from": payment_method["wallet_address"],
        "to": "0xMerchantAddress",
        "value": "100",
        "valid_after": "0",
        "valid_before": "9999999999",
        "nonce": "0xrandomnonce",
    }
    authorization = EIP3009Authorization(**authorization_payload)

    # The signature is a single bytes object, but some systems expect it as a
    # hex string with r, s, and v components concatenated.
    signature_hex = "0xmocksignature"

    exact_payload = ExactPaymentPayload(
        signature=signature_hex, authorization=authorization
    )

    return PaymentPayload(
        x402_version=1,
        scheme="exact",
        network=payment_method["network"],
        payload=exact_payload,
    ).model_dump()

  token = f"fake_payment_credential_token_{len(_token)}"

  _token[token] = {
      "email_address": email_address,
      "payment_method_alias": payment_method_alias,
      "payment_mandate_id": None,
  }

  return token


def update_token(token: str, payment_mandate_id: str) -> None:
  """Updates the token with the payment mandate id.

  Args:
    token: The token to update.
    payment_mandate_id: The payment mandate id to associate with the token.
  """
  if token not in _token:
    raise ValueError(f"Token {token} not found")
  if _token[token].get("payment_mandate_id"):
    return
  _token[token]["payment_mandate_id"] = payment_mandate_id


def update_token_by_transaction_id(transaction_id: str) -> None:
  """Binds the most recent unbound token to a transaction_id.

  This is used in the SDK mandate flow.

  Args:
    transaction_id: The transaction ID to bind to the token.
  """
  for tok_data in reversed(list(_token.values())):
    if not tok_data.get("payment_mandate_id"):
      tok_data["payment_mandate_id"] = transaction_id
      return
  raise ValueError("No unbound token found to associate with transaction_id")


def get_credentials_by_transaction_id(
    transaction_id: str,
) -> dict[str, Any] | None:
  """Look up payment credentials by transaction_id (SDK mandate flow)."""
  for tok_data in _token.values():
    if tok_data.get("payment_mandate_id") == transaction_id:
      email = tok_data.get("email_address")
      alias = tok_data.get("payment_method_alias")
      return get_payment_method_by_alias(email, alias)
  return None


def verify_token(token: str, payment_mandate_id: str) -> dict[str, Any]:
  """Look up an account by token.

  Args:
    token: The token for look up.
    payment_mandate_id: The payment mandate id associated with the token.

  Returns:
    The account for the given token, or status:invalid_token if the token is not
    valid.
  """
  account_lookup = _token.get(token, {})
  if not account_lookup:
    raise ValueError("Invalid token")
  if account_lookup.get("payment_mandate_id") != payment_mandate_id:
    raise ValueError("Invalid token")
  email_address = account_lookup.get("email_address")
  alias = account_lookup.get("payment_method_alias")
  return get_payment_method_by_alias(email_address, alias)


def get_account_payment_methods(email_address: str) -> list[dict[str, Any]]:
  """Returns a list of the payment methods for the given account email address.

  Args:
    email_address: The account's email address.

  Returns:
    A list of the user's payment_methods.
  """
  return list(
      _account_db.get(email_address, {}).get("payment_methods", {}).values()
  )


def get_account_shipping_address(email_address: str) -> dict[str, Any]:
  """Gets the shipping address associated for the given account email address.

  Args:
    email_address: The account's email address.

  Returns:
    The account's shipping address.
  """
  return _account_db.get(email_address, {}).get("shipping_address", {})


def get_payment_method_by_alias(
    email_address: str, alias: str
) -> dict[str, Any] | None:
  """Returns the payment method for a given account and alias.

  Args:
    email_address: The account's email address.
    alias: The alias of the payment method to retrieve.

  Returns:
    The payment method for the given account and alias, or status:not_found.
  """
  payment_methods = list(
      filter(
          lambda payment_method: payment_method.get("alias").casefold()
          == alias.casefold(),
          get_account_payment_methods(email_address),
      )
  )
  if not payment_methods:
    return None
  return payment_methods[0]
