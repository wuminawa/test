"""Public x402 defaults and local wallet configuration."""

import os


# Standard local development address (Anvil/Hardhat Account 0)
DEFAULT_USER_ADDRESS = "0xf39Fd6e51aad88F6F4ce6aB8827279cffFb92266"

# Standard merchant receiver (Anvil/Hardhat Account 1)
DEFAULT_MERCHANT_ADDRESS = "0x70997970C51812dc3A010C7d01b50e0d17dc79C8"

# Standard facilitator relayer (Anvil/Hardhat Account 2)
DEFAULT_FACILITATOR_ADDRESS = "0x3C44CdDdB6a900fa2b585dd299e03d12FA4293BC"

# Base Sepolia Constants
DEFAULT_USDC_CONTRACT = "0x036CbD53842c5426634e7929541eC2318f3dCF7e"
DEFAULT_RPC_URL = "https://sepolia.base.org"


def get_user_private_key() -> str:
  """Require an explicitly configured wallet key instead of a shared default."""
  private_key = os.environ.get("X402_USER_PRIVATE_KEY", "").strip()
  if not private_key:
    raise RuntimeError(
        "X402_USER_PRIVATE_KEY is required for the human-not-present x402"
        " sample. Set it in the local .env file or process environment."
    )
  return private_key
