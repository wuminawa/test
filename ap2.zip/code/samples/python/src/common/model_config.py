# Copyright 2026 Google LLC
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     https://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Shared model-provider configuration for the Python samples."""

import os

from typing import Any


DEFAULT_GOOGLE_MODEL = "gemini-3.1-flash-lite-preview"
DEFAULT_DEEPSEEK_MODEL = "deepseek-v4-flash"
DEFAULT_DEEPSEEK_API_BASE = "https://api.deepseek.com"

_PROVIDER_ALIASES = {
    "google": "google",
    "gemini": "google",
    "deepseek": "deepseek",
    "ds": "deepseek",
}


def get_model_provider() -> str:
  """Returns the normalized model provider selected for the samples."""
  configured_provider = os.environ.get("AGENT_MODEL_PROVIDER", "google")
  provider = configured_provider.strip().lower()
  try:
    return _PROVIDER_ALIASES[provider]
  except KeyError as exc:
    supported = ", ".join(sorted(_PROVIDER_ALIASES))
    raise ValueError(
        "Unsupported AGENT_MODEL_PROVIDER="
        f"{configured_provider!r}. Supported values: {supported}."
    ) from exc


def get_google_model_name() -> str:
  """Returns the Gemini model name used by Google-backed agents."""
  return os.environ.get("AGENT_MODEL", DEFAULT_GOOGLE_MODEL).strip()


def get_deepseek_model_name(*, include_provider_prefix: bool = True) -> str:
  """Returns the configured DeepSeek model name.

  LiteLLM requires the ``deepseek/`` provider prefix, while DeepSeek's native
  API accepts the unprefixed model name. This helper supports both forms.
  """
  model = os.environ.get("DEEPSEEK_MODEL", DEFAULT_DEEPSEEK_MODEL).strip()
  if not model:
    raise ValueError("DEEPSEEK_MODEL must not be empty.")
  if include_provider_prefix:
    return model if model.startswith("deepseek/") else f"deepseek/{model}"
  return model.removeprefix("deepseek/")


def get_deepseek_api_base() -> str:
  """Returns the DeepSeek OpenAI-compatible API base URL."""
  api_base = os.environ.get(
      "DEEPSEEK_API_BASE", DEFAULT_DEEPSEEK_API_BASE
  ).strip()
  if not api_base:
    raise ValueError("DEEPSEEK_API_BASE must not be empty.")
  return api_base.rstrip("/")


def require_provider_credentials() -> None:
  """Raises a clear error when the selected provider has no credentials."""
  if get_model_provider() != "deepseek":
    return
  if not os.environ.get("DEEPSEEK_API_KEY", "").strip():
    raise RuntimeError(
        "DeepSeek is selected but DEEPSEEK_API_KEY is empty. Add the key to"
        " the repository-root .env file."
    )


def get_agent_model() -> Any:
  """Returns a model value suitable for a Google ADK ``Agent``.

  Google models use ADK's built-in string registry. DeepSeek models use ADK's
  LiteLLM connector and obtain their secret from ``DEEPSEEK_API_KEY``.
  """
  provider = get_model_provider()
  if provider == "google":
    return get_google_model_name()

  require_provider_credentials()
  try:
    from google.adk.models.lite_llm import LiteLlm
  except ImportError as exc:
    raise RuntimeError(
        "DeepSeek support is not installed. Run `uv sync --package"
        " ap2-samples` from the repository root."
    ) from exc

  return LiteLlm(
      model=get_deepseek_model_name(),
      api_base=get_deepseek_api_base(),
  )


def deepseek_completion(**kwargs: Any) -> Any:
  """Calls DeepSeek through LiteLLM without copying the key into code."""
  require_provider_credentials()
  try:
    from litellm import completion
  except ImportError as exc:
    raise RuntimeError(
        "DeepSeek support is not installed. Run `uv sync --package"
        " ap2-samples` from the repository root."
    ) from exc

  return completion(
      model=get_deepseek_model_name(),
      api_base=get_deepseek_api_base(),
      **kwargs,
  )
