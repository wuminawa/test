# Agent Payments Protocol Sample: Human Not Present Purchases with a Card

This sample demonstrates a **Human-Not-Present** transaction using a card as the
payment method.

## Scenario

Human-Not-Present flows refer to all commerce flows where the user is **not
actively present** to confirm the details of what is being purchased at the
exact moment of the transaction. Instead, the user has pre-authorized the
transaction details and payment method (e.g., by setting up a specific intent or
agreeing to a purchase condition like a price drop).

In this scenario, the flow is triggered by a mock "price drop" or "item drop"
event from the merchant. Once the price drops to a level acceptable to the agent
(based on user intent), the Shopping Agent autonomously completes the purchase
using the pre-authorized credentials and mandates, without asking the user for
real-time confirmation.

## Key Actors

This sample consists of:

- **Shopping Agent (v2):** The main orchestrator that handles the user's
  shopping requests and acts autonomously when a trigger condition is met.
- **Merchant Agent (MCP):** An agent that handles product queries and advertises
  support for card purchases.
- **Merchant Payment Processor Agent (MCP):** An agent that takes payments on
  behalf of the merchant.
- **Credentials Provider Agent (MCP):** The holder of the user's payment
  credentials, facilitating payment between the shopping agent and the
  merchant's payment processor.

## Key Features

**1. Autonomous Purchase on Trigger**

- The flow is initiated by an external trigger (a mock price drop or item drop)
  rather than a direct user command at the moment of purchase.
- The agent evaluates the condition and proceeds with the purchase if it matches
  the user's intent.

**2. Pre-authorized Mandate Usage**

- The agent leverages a pre-authorized mandate to interact with the credentials
  provider and payment processor.

**3. Card purchase with DPAN**

- The preferred payment method is a tokenized (DPAN) card, managed by the
  Credentials Provider.

## Executing the Example

### Setup

Configure either DeepSeek or Google in the repository-root `.env` file. For
DeepSeek, set `AGENT_MODEL_PROVIDER=deepseek` and paste the key after
`DEEPSEEK_API_KEY=`. See the central
[`Python samples README`](../../../../README.md#configuration) for the complete
configuration.

### Execution

You can execute the following command to run all services (Merchant Trigger,
Credentials Provider, Merchant Payment Processor, Shopping Agent, and Web
Client) in one terminal:

```sh
bash code/samples/python/scenarios/a2a/human-not-present/cards/run.sh
```

This script will start the services on the following ports:

- Agent: `8080`
- Merchant Trigger: `8081`
- Credentials Provider: `8082`
- Payment Processor: `8083`
- Web Client: `5173`

The script will automatically open the web client in your browser. If not, you
can open `http://localhost:5173` manually.

### Triggering the Flow

To simulate the trigger condition (e.g., a price drop), open a separate terminal
and run the following command (replace `<item_id>` and `<price>` with
appropriate test values):

```sh
curl -X POST \
  "http://localhost:8081/trigger-price-drop?item_id=<item_id>&price=<price>&stock=10"
```

Observe the web client to see the autonomous purchase in action.
