#!/bin/bash

# Validate model-provider settings after a scenario has loaded its .env files.
# This file is intended to be sourced by the scenario run scripts.

MODEL_PROVIDER=$(printf "%s" "${AGENT_MODEL_PROVIDER:-google}" | tr '[:upper:]' '[:lower:]')

case "$MODEL_PROVIDER" in
  deepseek | ds)
    export AGENT_MODEL_PROVIDER="deepseek"
    if [ -z "${DEEPSEEK_API_KEY:-}" ]; then
      echo "DeepSeek is selected but DEEPSEEK_API_KEY is empty."
      echo "Add it to the repository-root .env file, then run this script again."
      return 1
    fi
    ;;
  google | gemini)
    export AGENT_MODEL_PROVIDER="google"
    USE_VERTEXAI=$(printf "%s" "${GOOGLE_GENAI_USE_VERTEXAI:-}" | tr '[:upper:]' '[:lower:]')
    if [ -z "${GOOGLE_API_KEY:-}" ] && [ "$USE_VERTEXAI" != "true" ]; then
      echo "Google is selected but GOOGLE_API_KEY is empty."
      echo "Alternatively, set GOOGLE_GENAI_USE_VERTEXAI=true to use Vertex AI with ADC."
      return 1
    fi
    ;;
  *)
    echo "Unsupported AGENT_MODEL_PROVIDER: ${AGENT_MODEL_PROVIDER:-}"
    echo "Use google or deepseek."
    return 1
    ;;
esac

echo "Using model provider: $AGENT_MODEL_PROVIDER"
