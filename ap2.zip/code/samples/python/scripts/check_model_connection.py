#!/usr/bin/env python3
"""Fail fast when the selected model credentials or model are unusable."""

import os
import sys

import httpx

from common.model_config import (
  get_deepseek_api_base,
  get_deepseek_model_name,
  get_model_provider,
  require_provider_credentials,
)


HTTP_OK = 200


def check_deepseek_connection() -> None:
  """Validates the key and selected model through DeepSeek's models API."""
  require_provider_credentials()
  api_key = os.environ["DEEPSEEK_API_KEY"]
  try:
    response = httpx.get(
        f"{get_deepseek_api_base()}/models",
        headers={"Authorization": f"Bearer {api_key}"},
        timeout=20,
    )
  except httpx.HTTPError as exc:
    raise RuntimeError(
        f"Could not reach the DeepSeek API: {type(exc).__name__}."
    ) from exc

  if response.status_code != HTTP_OK:
    raise RuntimeError(
        "DeepSeek rejected the credentials or request"
        f" (HTTP {response.status_code})."
    )

  payload = response.json()
  available_models = {
      item.get("id")
      for item in payload.get("data", [])
      if isinstance(item, dict)
  }
  selected_model = get_deepseek_model_name(include_provider_prefix=False)
  if selected_model not in available_models:
    available = ", ".join(sorted(model for model in available_models if model))
    raise RuntimeError(
        f"DeepSeek model {selected_model!r} is unavailable. Available models:"
        f" {available or 'none reported'}."
    )

  print(f"DeepSeek authentication OK; model available: {selected_model}")


def main() -> int:
  """Checks the selected provider and returns a process exit status."""
  try:
    provider = get_model_provider()
    if provider == "deepseek":
      check_deepseek_connection()
    else:
      print("Google model configuration selected.")
  except (RuntimeError, ValueError) as exc:
    print(f"Model preflight failed: {exc}", file=sys.stderr)
    return 1
  return 0


if __name__ == "__main__":
  raise SystemExit(main())
