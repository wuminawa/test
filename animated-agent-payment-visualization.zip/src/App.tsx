import { useEffect, useState } from "react";

type Actor = { id: string; name: string; color: string; icon: string };
// icon = svg path (24x24 viewbox, stroke)
const ACTORS: Actor[] = [
  { id: "user", name: "User", color: "#4C72B0", icon: "M12 12a4 4 0 1 0 0-8 4 4 0 0 0 0 8zM4 21c0-4 4-6 8-6s8 2 8 6" },
  { id: "agent", name: "Shopping Agent", color: "#DD8452", icon: "M5 8h14v11H5zM12 4v4M9 13h.01M15 13h.01M9 16h6M2 12v3M22 12v3" },
  { id: "ts", name: "Trusted Surface", color: "#55A868", icon: "M12 3l8 3v6c0 5-3.5 8-8 9-4.5-1-8-4-8-9V6z M9 12l2 2 4-4" },
  { id: "cp", name: "Credential Provider", color: "#8172B3", icon: "M3 6h18v12H3zM3 10h18M7 15h4" },
  { id: "net", name: "Network", color: "#C44E52", icon: "M12 3a9 9 0 1 0 0 18 9 9 0 0 0 0-18zM3 12h18M12 3c3 3 3 15 0 18M12 3c-3 3-3 15 0 18" },
  { id: "mer", name: "Merchant", color: "#937860", icon: "M4 9l1-5h14l1 5M4 9v11h16V9M4 9h16M10 20v-6h4v6" },
  { id: "mpp", name: "Merchant Payment Processor", color: "#DA8BC3", icon: "M4 4h16v16H4zM8 8h8M8 12h8M8 16h4" },
  { id: "net2", name: "network", color: "#8C8C8C", icon: "M6 6a2 2 0 1 0 0 .01M18 6a2 2 0 1 0 0 .01M12 18a2 2 0 1 0 0 .01M7 7l4 9M17 7l-4 9M8 6h8" },
];

type Step = { from: string; to: string; label: string; dashed?: boolean; desc: string };
const STEPS: Step[] = [
  { from: "agent", to: "agent", label: "Selects appropriate Open Mandates", desc: "Shopping Agent 思考中：挑选合适的 Open Mandate" },
  { from: "agent", to: "agent", label: "Sign Closed Checkout & Payment Mandate w/ agent_sk", desc: "Agent 使用 agent_sk 签名 Closed Mandate" },
  { from: "agent", to: "cp", label: "Payment Mandates (Open, Closed)", desc: "Agent 将支付授权发送给 Credential Provider" },
  { from: "cp", to: "cp", label: "Verify Payment Mandates and Constraints", desc: "Credential Provider 校验授权与约束" },
  { from: "cp", to: "net", label: "Payment Mandate", dashed: true, desc: "转发 Payment Mandate 至卡组织网络" },
  { from: "net", to: "net", label: "Verify Payment Mandate and Constraints", dashed: true, desc: "Network 校验授权与约束" },
  { from: "net", to: "cp", label: "payment_token", dashed: true, desc: "Network 签发 payment_token" },
  { from: "cp", to: "agent", label: "payment_token", desc: "payment_token 返回给 Agent" },
  { from: "agent", to: "mer", label: "Checkout (CheckoutMandates (Open, Closed), payment_token)", desc: "Agent 向商户发起结账" },
  { from: "mer", to: "mpp", label: "initiate payment (payment_token, hash(Checkout_jwt), hash(open CheckoutMandate))", desc: "商户请求支付处理方发起扣款" },
  { from: "mpp", to: "mpp", label: "verify Payment Mandates", desc: "支付处理方校验授权" },
  { from: "mpp", to: "cp", label: "Signed Payment Receipt", dashed: true, desc: "签名支付回执返回 Credential Provider" },
  { from: "cp", to: "net2", label: "Signed Payment Receipt", dashed: true, desc: "回执同步至 network" },
  { from: "mer", to: "agent", label: "Signed Checkout Receipt", desc: "商户返回签名结账回执，流程结束" },
];

const W = 1400, COLW = 165, X0 = 80, TOP = 110, ROWH = 52;
const xOf = (id: string) => X0 + ACTORS.findIndex((a) => a.id === id) * COLW;
const yOf = (i: number) => TOP + 70 + i * ROWH;
const BOTTOM = yOf(STEPS.length) + 10;
const H = BOTTOM + 70;

function ActorBox({ a, y, active }: { a: Actor; y: number; active: boolean }) {
  const x = xOf(a.id);
  return (
    <g transform={`translate(${x},${y})`}>
      <rect x={-72} y={-24} width={144} height={48} rx={6} fill={active ? a.color : "#fff"} stroke={a.color} strokeWidth={active ? 2.5 : 1.5}
        style={{ transition: "all .3s", filter: active ? `drop-shadow(0 0 8px ${a.color})` : "none" }} />
      <g transform="translate(-64,-10) scale(0.85)" fill="none" stroke={active ? "#fff" : a.color} strokeWidth={1.8} strokeLinecap="round" strokeLinejoin="round">
        <path d={a.icon} />
      </g>
      <text x={8} y={4} textAnchor="middle" fontSize={a.name.length > 18 ? 10.5 : 12.5} fill={active ? "#fff" : "#222"} fontFamily="Georgia, serif">
        {a.name.length > 22 ? <><tspan x={10} dy={-5}>Merchant Payment</tspan><tspan x={10} dy={13}>Processor</tspan></> : a.name}
      </text>
    </g>
  );
}

export default function App() {
  const [cur, setCur] = useState(-1);
  const [playing, setPlaying] = useState(false);

  useEffect(() => {
    if (!playing) return;
    if (cur >= STEPS.length - 1) { setPlaying(false); return; }
    const t = setTimeout(() => setCur((c) => c + 1), 1800);
    return () => clearTimeout(t);
  }, [playing, cur]);

  const step = STEPS[cur];
  const activeIds = step ? [step.from, step.to] : [];

  return (
    <div className="min-h-screen bg-[#fafaf7] text-[#222] flex" style={{ fontFamily: "Georgia, 'Times New Roman', serif" }}>
      <style>{`
        @keyframes dash { to { stroke-dashoffset: -24; } }
        .flow { animation: dash .6s linear infinite; }
        @keyframes pulse { 0%,100%{opacity:.25} 50%{opacity:.6} }
        .pulse { animation: pulse 1.2s ease-in-out infinite; }
      `}</style>
      <aside className="w-80 shrink-0 border-r border-[#ddd] bg-white p-5 flex flex-col gap-3 h-screen sticky top-0 overflow-auto">
        <h1 className="text-xl font-bold">Agent Payments</h1>
        <p className="text-xs text-[#666] italic">Human-Not-Present Payment Flow — interactive demo</p>
        <div className="grid grid-cols-2 gap-2 text-sm">
          <button className="border border-[#333] px-2 py-1.5 hover:bg-[#333] hover:text-white" onClick={() => setPlaying((p) => !p)}>{playing ? "⏸ Pause" : "▶ Auto Play"}</button>
          <button className="border border-[#333] px-2 py-1.5 hover:bg-[#333] hover:text-white" onClick={() => { setPlaying(false); setCur(-1); }}>↺ Reset</button>
          <button className="border border-[#333] px-2 py-1.5 hover:bg-[#333] hover:text-white" onClick={() => setCur((c) => Math.max(-1, c - 1))}>← Prev</button>
          <button className="border border-[#333] px-2 py-1.5 hover:bg-[#333] hover:text-white" onClick={() => setCur((c) => Math.min(STEPS.length - 1, c + 1))}>Next →</button>
        </div>
        <div className="text-xs uppercase tracking-wider text-[#888] mt-2">Trigger stage</div>
        <ol className="flex flex-col gap-1">
          {STEPS.map((s, i) => (
            <li key={i}>
              <button onClick={() => { setPlaying(false); setCur(i); }}
                className={`w-full text-left text-xs px-2 py-1.5 border-l-4 transition ${i === cur ? "bg-[#1f3a5f] text-white border-[#DD8452]" : i < cur ? "border-[#55A868] text-[#555]" : "border-transparent hover:bg-[#f0f0ea]"}`}>
                <span className="font-mono mr-1">{String(i + 1).padStart(2, "0")}</span>{s.desc}
              </button>
            </li>
          ))}
        </ol>
      </aside>

      <main className="flex-1 p-6 overflow-auto">
        <div className="bg-white border border-[#ddd] shadow-sm p-4">
          <div className="flex items-baseline justify-between mb-2 px-2">
            <h2 className="text-lg"><b>Figure 1.</b> <i>Human Not Present Payment flow</i></h2>
            <span className="text-sm text-[#555]">
              {step ? <>Step {cur + 1}/{STEPS.length}: <b>{step.desc}</b></> : "Idle — press ▶ or select a stage"}
            </span>
          </div>
          <svg viewBox={`0 0 ${W} ${H}`} className="w-full min-w-[1100px]">
            <defs>
              {["#333", "#c0392b", "#bbb"].map((c, i) => (
                <marker key={i} id={`ar${i}`} viewBox="0 0 10 10" refX={9} refY={5} markerWidth={7} markerHeight={7} orient="auto-start-reverse">
                  <path d="M0 0L10 5L0 10z" fill={c} />
                </marker>
              ))}
            </defs>
            {ACTORS.map((a) => (
              <line key={a.id} x1={xOf(a.id)} x2={xOf(a.id)} y1={TOP - 40} y2={H - 40} stroke={activeIds.includes(a.id) ? a.color : "#bbb"} strokeWidth={activeIds.includes(a.id) ? 2 : 1} strokeDasharray="4 4" />
            ))}
            {[TOP + 30, BOTTOM].map((y, i) => (
              <g key={i}>
                <rect x={X0 - 70} y={y - 14} width={xOf("mpp") - X0 + 150} height={26} fill={(i === 0 ? cur >= 0 : cur === STEPS.length - 1) ? "#2e6b3a" : "#e8efe8"} stroke="#2e6b3a" style={{ transition: "fill .4s" }} />
                <text x={(X0 - 70 + xOf("mpp") + 80) / 2} y={y + 4} textAnchor="middle" fontSize={13} fill={(i === 0 ? cur >= 0 : cur === STEPS.length - 1) ? "#fff" : "#2e6b3a"}>{i === 0 ? "Start Payment Journey" : "End Payment Journey"}</text>
              </g>
            ))}
            {STEPS.map((s, i) => {
              const y = yOf(i), x1 = xOf(s.from), x2 = xOf(s.to);
              const active = i === cur, done = i < cur;
              const color = active ? "#c0392b" : done ? "#333" : "#bbb";
              const m = `url(#ar${active ? 1 : done ? 0 : 2})`;
              const sw = active ? 2.5 : 1.3;
              const dash = active ? "8 4" : s.dashed ? "6 4" : undefined;
              const self = s.from === s.to;
              const d = self ? `M${x1} ${y - 12} h30 v24 h-28` : `M${x1} ${y} L${x2 + (x2 > x1 ? -2 : 2)} ${y}`;
              const tx = self ? x1 + 40 : (x1 + x2) / 2;
              return (
                <g key={i} style={{ cursor: "pointer" }} onClick={() => { setPlaying(false); setCur(i); }}>
                  {active && <rect className="pulse" x={Math.min(x1, x2) - 20} y={y - 26} width={self ? 420 : Math.abs(x2 - x1) + 40} height={44} fill="#f6d7b0" rx={4} />}
                  <path d={d} fill="none" stroke={color} strokeWidth={sw} strokeDasharray={dash} className={active ? "flow" : ""} markerEnd={m} />
                  {active && !self && (
                    <circle r={6} fill="#c0392b">
                      <animate attributeName="cx" from={x1} to={x2} dur="1.2s" repeatCount="indefinite" />
                      <animate attributeName="cy" from={y} to={y} dur="1.2s" repeatCount="indefinite" />
                    </circle>
                  )}
                  {active && self && (
                    <g transform={`translate(${x1 - 22},${y})`}>
                      {[0, 1, 2].map((k) => (
                        <circle key={k} cx={k * 7 - 7} cy={0} r={2.5} fill="#c0392b">
                          <animate attributeName="opacity" values="0.2;1;0.2" dur="1s" begin={`${k * 0.2}s`} repeatCount="indefinite" />
                        </circle>
                      ))}
                    </g>
                  )}
                  <text x={tx} y={self ? y + 4 : y - 7} textAnchor={self ? "start" : "middle"} fontSize={12.5} fill={active ? "#8b1e12" : done ? "#222" : "#999"} fontWeight={active ? "bold" : "normal"}>
                    <tspan fontFamily="monospace" fontSize={10}>({i + 1}) </tspan>{s.label}
                  </text>
                </g>
              );
            })}
            {ACTORS.map((a) => (
              <g key={a.id}>
                <ActorBox a={a} y={TOP - 50} active={activeIds.includes(a.id)} />
                <ActorBox a={a} y={H - 30} active={activeIds.includes(a.id)} />
              </g>
            ))}
          </svg>
          <p className="text-xs text-[#666] mt-2 px-2 italic">Solid arrows: synchronous messages; dashed: network-side messages. Red: current data flow; black: completed; grey: pending. Click any arrow to jump.</p>
        </div>
      </main>
    </div>
  );
}
